package Classes;

public class ControlFlow {
    private int property;
	
	public int getProperty() {
        return property;
    }
	public void modifyStat() {
		
	}
}
