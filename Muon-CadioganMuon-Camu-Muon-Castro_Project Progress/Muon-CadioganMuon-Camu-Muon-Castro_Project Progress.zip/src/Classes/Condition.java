package Classes;

public class Condition {
    private int property;
		
	public int getProperty() {
        	return property;
    	}
	
	public void modifyCF(){
		
	}
}
